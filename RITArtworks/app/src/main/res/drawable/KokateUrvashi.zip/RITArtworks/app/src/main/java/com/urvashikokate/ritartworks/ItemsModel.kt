package com.urvashikokate.ritartworks

import java.net.URL

class ItemsModel(

    var name: String="",
    var price: String="",
    var description: String = "",
    var category: String="",
    var image: String ="",
    var seller: String = "",
    var uid: String = ""
) {


    constructor() : this(" ", "","","","","","")
}



